# DB
my_db = None
